from django.http.response import HttpResponse
from django.shortcuts import redirect, render
from django import template
import folium
#import pandas as pd
import webbrowser
import geocoder
from .models import Search
from .forms import Searchform
# Create your views here.

def home(request):
    if request.method=='POST':
        form=Searchform(request.POST)
        if form.is_valid():
            form.save()
            return redirect('/')

    else:
        form=Searchform()    

    
    address=Search.objects.all().last()
    loc=geocoder.osm(address)

    latitude=loc.lat
    langitude=loc.lng
    
    if latitude==None or langitude==None: 
        address.delete()
        return HttpResponse('<h1>Invalid Address..</h1>')
    #country=loc.country
    # Create Map Object
    m=folium.Map(location=[19,-12],zoom_start=2)
    folium.Marker([latitude,langitude],tooltip='Click for More',popup=address).add_to(m)
    # Get HTML representation of Map Object
    m1=m._repr_html_()
    context={
        'map':m1,
        'form':form,
        'lat':latitude,
        'lng':latitude,
        'loc':address

    }

    
    return render(request,'index.html',context=context)
